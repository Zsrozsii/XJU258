<!-- Ikonok css használata -->
<div class="col item social">
                        <a href="https://facebook.com"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
                        <a href="https://twitter.com"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
                        <a href="https://snapchat.com"><i class="fa fa-snapchat" aria-hidden="true"></i></a>
                        <a href="https://instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
